import json
import os
from web3 import Web3
import requests
from datetime import datetime

def load_rpc_options():
    with open("rpc_config.json", "r") as f:
        return json.load(f)

def select_network():
    options = load_rpc_options()
    print("🌐 Chọn mạng EVM:")
    for i, net in enumerate(options.keys()):
        print(f"{i+1}. {net}")
    idx = int(input("→ Chọn số: ")) - 1
    name = list(options.keys())[idx]
    return name, options[name]["rpc_url"]

def load_telegram_config():
    with open("telegram_config.json", "r") as f:
        return json.load(f)

def send_to_telegram(message):
    config = load_telegram_config()
    url = f"https://api.telegram.org/bot{config['token']}/sendMessage"
    payload = {
        "chat_id": config['chat_id'],
        "text": message,
        "parse_mode": "Markdown"
    }
    try:
        requests.post(url, json=payload)
    except Exception as e:
        print("❌ Telegram error:", e)

ERC20_ABI = [
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "type": "function",
    },
    {
        "constant": True,
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "type": "function",
    },
    {
        "constant": True,
        "inputs": [],
        "name": "symbol",
        "outputs": [{"name": "", "type": "string"}],
        "type": "function",
    },
]

TOKEN_LIST = {
    "USDT": "0x55d398326f99059fF775485246999027B3197955",
    "BUSD": "0xe9e7cea3dedca5984780bafc599bd69add087d56",
    "CAKE": "0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82"
}

def save_to_file(wallet_address, content):
    os.makedirs("result_logs", exist_ok=True)
    filename = f"result_logs/{wallet_address.lower()}.txt"
    with open(filename, "a") as f:
        f.write(f"
[{datetime.now()}]
{content}
")

def get_token_price(symbol):
    try:
        url = f"https://api.coingecko.com/api/v3/simple/price?ids={symbol.lower()}&vs_currencies=usd"
        response = requests.get(url).json()
        return response[symbol.lower()]['usd']
    except:
        return 0

def run_check():
    wallet_address = input("🔐 Nhập địa chỉ ví cần kiểm tra: ").strip()
    if not wallet_address:
        return "❌ Địa chỉ ví không hợp lệ."

    network_name, rpc_url = select_network()
    w3 = Web3(Web3.HTTPProvider(rpc_url))
    if not w3.isConnected():
        return "❌ RPC không kết nối được."

    results = []
    for name, contract_address in TOKEN_LIST.items():
        try:
            contract = w3.eth.contract(address=Web3.toChecksumAddress(contract_address), abi=ERC20_ABI)
            balance = contract.functions.balanceOf(Web3.toChecksumAddress(wallet_address)).call()
            decimals = contract.functions.decimals().call()
            symbol = contract.functions.symbol().call()
            adjusted_balance = balance / (10 ** decimals)
            if adjusted_balance > 0:
                price = get_token_price(symbol)
                usd_value = adjusted_balance * price
                if usd_value >= 1:
                    results.append(f"• *{symbol}*: `{adjusted_balance:.4f}` ~ 💲{usd_value:,.2f}")
        except Exception as e:
            print(f"⚠️ Lỗi đọc {name}: {e}")

    if results:
        message = f"📊 *Tài sản ví:* `{wallet_address}` trên mạng `{network_name}`

" + "
".join(results)
    else:
        message = f"📭 Không có token nào >1 USDT trong ví `{wallet_address}`."

    send_to_telegram(message)
    save_to_file(wallet_address, message)
    return message

if __name__ == "__main__":
    run_check()
