import time
from bot import run_check

def run_all():
    with open("wallets.txt", "r") as f:
        addresses = [line.strip() for line in f if line.strip()]
    for addr in addresses:
        print(f"🔁 Kiểm tra ví: {addr}")
        run_check(wallet_override=addr)
        time.sleep(2)

if __name__ == "__main__":
    run_all()
