import json
from telegram import Update
from telegram.ext import Updater, CommandHandler, CallbackContext
from bot import run_check

with open("telegram_config.json", "r") as f:
    config = json.load(f)

def check_command(update: Update, context: CallbackContext):
    update.message.reply_text("🔍 Đang kiểm tra ví...")
    result = run_check()
    update.message.reply_text(result)

updater = Updater(config["token"])
updater.dispatcher.add_handler(CommandHandler("check", check_command))
updater.start_polling()
