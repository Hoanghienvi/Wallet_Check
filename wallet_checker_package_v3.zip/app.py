from flask import Flask, render_template_string, request
from bot import run_check

app = Flask(__name__)

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Wallet Checker</title>
</head>
<body>
    <h2>Check ví crypto</h2>
    <form method="post">
        Địa chỉ ví: <input type="text" name="wallet" required>
        <button type="submit">Check</button>
    </form>
    {% if result %}
    <pre>{{ result }}</pre>
    {% endif %}
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        wallet = request.form["wallet"]
        result = run_check(wallet_override=wallet)
    return render_template_string(HTML, result=result)

if __name__ == "__main__":
    app.run(debug=True)
